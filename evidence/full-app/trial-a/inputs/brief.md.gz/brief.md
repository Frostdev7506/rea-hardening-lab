# Compiled application reconstruction

The four primary files are browser.js, planner.js, persistence.js and page.js. Shared quote-* files represent the legacy quote feature, outside the V2 hardening treatment; report its parity separately. CSS and screenshots are public presentation aids shared identically by both trials. Recover application behavior from the files; the owner will supply no source or expected test answers.

Run REA using Node 24:

node /Users/neeraj/.codex/tmp/rea-hardening-lab-tools/runtime/node_modules/rea-agents/scripts/rea.mjs analyze-javascript-application inputs --max-semantic-nodes 12000 --max-semantic-nodes-per-file 12000 --max-semantic-unknowns 4000 --max-semantic-unknowns-per-file 4000 --analysis-timeout-ms 60000 --max-heap-mb 1024 --format json > rea-analysis.json

Record the actual CLI output/coverage and your evidence use. If scanning the whole directory is unwieldy, scan individual supplied files or a dedicated primary-only subdirectory with the same limits and retain the report.

All framework packages are already present at app/node_modules. Use npm run build in app/ and npm start -- --port PORT for production. SQLite via node:sqlite is available. Do not install packages or use external services. Your own local app requests/self-tests are allowed; queries to the original or another reconstruction are forbidden. Keep output sources independent of the supplied compiled files.
